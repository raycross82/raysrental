(function(){
  var $=function(s){return document.querySelector(s)};
  var fmt=function(n){return '$'+(n%1?n.toFixed(2):n)};
  var qtyIds=['tables','chairs','coolers','speakers'];

  function state(){
    var pkg=document.querySelector('input[name=package]:checked');
    var pkgPrice=+(pkg.dataset.price||0);
    var items=[],sub=pkgPrice;
    if(pkgPrice) items.push({name:pkg.value+' package',qty:1,line:pkgPrice});
    qtyIds.forEach(function(id){
      var el=$('#q-'+id),q=Math.max(0,+el.value||0),p=+el.dataset.price;
      if(q>0){items.push({name:el.dataset.name,qty:q,line:q*p});sub+=q*p;}
    });
    var delivery=document.querySelector('input[name=fulfillment]:checked').value!=='Free Pickup';
    return {items:items,sub:sub,delivery:delivery,total:sub,deposit:sub*0.25};
  }

  function renderSummary(){
    var s=state(),lines=$('#cart-lines');
    lines.innerHTML=s.items.length?'':'<p class="note" id="cart-empty">Your cart is empty &mdash; pick a package or add items to begin.</p>';
    s.items.forEach(function(it){
      var d=document.createElement('div');d.className='sline';
      d.innerHTML='<span>'+it.qty+' &times; '+it.name+'</span><span>'+fmt(it.line)+'</span>';
      lines.appendChild(d);
    });
    $('#s-subtotal').textContent=fmt(s.sub);
    $('#s-fulfill').textContent=s.delivery?'Priced by location':'Free';
    $('#s-total').textContent=fmt(s.total)+(s.delivery?' + delivery':'');
    $('#s-deposit').textContent=fmt(s.deposit);
    $('#s-balance').textContent=fmt(s.total-s.deposit);
    $('#f-items').value=s.items.map(function(i){return i.qty+'x '+i.name}).join('; ')||'none';
    $('#f-total').value=fmt(s.total)+(s.delivery?' + delivery':'');
    $('#f-deposit').value=fmt(s.deposit);
  }

  document.querySelectorAll('.qty-ctl button').forEach(function(b){
    b.addEventListener('click',function(){
      var el=$('#q-'+b.dataset.q);
      el.value=Math.max(0,Math.min(+el.max,(+el.value||0)+(+b.dataset.d)));
      renderSummary();
    });
  });
  document.querySelectorAll('#quoteForm input').forEach(function(el){
    el.addEventListener('change',renderSummary);
    el.addEventListener('input',renderSummary);
  });
  $('#clearAll').addEventListener('click',function(){
    document.querySelector('input[name=package][value=none]').checked=true;
    qtyIds.forEach(function(id){$('#q-'+id).value=0});
    renderSummary();
  });

  // preselect package from ?package=
  var m=(location.search.match(/[?&]package=([^&]+)/)||[])[1];
  if(m){var r=document.querySelector('input[name=package][data-id="'+m+'"]');if(r)r.checked=true;}
  renderSummary();
})();
